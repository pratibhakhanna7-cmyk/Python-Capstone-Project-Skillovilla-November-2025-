import pandas as pd
import numpy as np
from tabulate import tabulate  # Optional: for pretty printing

# ---------------- Task 1: Create DataFrames ----------------
project_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005", "A002", "A005", "A003", "A001", "A003", "A001", "A004", "A003", "A005"],
    "Project": ["Project 1", "Project 2", "Project 3", "Project 4", "Project 5",
                "Project 6", "Project 7", "Project 8", "Project 9", "Project 10",
                "Project 11", "Project 12", "Project 13", "Project 14"],
    "Cost": [1002000, 2000000, 4500000, 5500000, None, 680000, 400000, 350000, None, 300000, 2000000, 10000000, 3000000, 200000],
    "Status": ["Finished", "Ongoing", "Finished", "Ongoing", "Finished",
               "Failed", "Finished", "Failed", "Ongoing", "Finished",
               "Failed", "Ongoing", "Finished", "Finished"]
}
employee_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005"],
    "Name": ["John Alter", "Alice Luxumberg", "Tom Sabestine", "Nina Adgra", "Amy Johny"],
    "Gender": ["M", "F", "M", "F", "F"],
    "City": ["Paris", "London", "Berlin", "Newyork", "Madrid"],
    "Age": [25, 27, 29, 31, 30]
}
seniority_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005"],
    "Designation Level": [2, 2, 3, 2, 3]
}

project_df = pd.DataFrame(project_data)
employee_df = pd.DataFrame(employee_data)
seniority_df = pd.DataFrame(seniority_data)

# ---------------- Task 2: Fill missing Cost using running average ----------------
running_sum = 0
count = 0
for i in range(len(project_df)):
    if pd.notna(project_df.loc[i, 'Cost']):
        running_sum += project_df.loc[i, 'Cost']
        count += 1
    else:
        project_df.loc[i, 'Cost'] = running_sum / count if count > 0 else 0
project_df['Cost'] = project_df['Cost'].astype(int)

# ---------------- Task 3: Split Name ----------------
employee_df[['First Name', 'Last Name']] = employee_df['Name'].str.split(' ', 1, expand=True)
employee_df.drop(columns=['Name'], inplace=True)

# ---------------- Task 4: Merge ----------------
final_df = project_df.merge(employee_df, on='ID', how='left').merge(seniority_df, on='ID', how='left')

# ---------------- Task 5: Bonus ----------------
final_df['Bonus'] = np.where(final_df['Status'] == 'Finished', final_df['Cost']*0.05, 0)

# ---------------- Task 6: Corrected Demotion & Removal ----------------
failed_ids = final_df[final_df['Status']=='Failed']['ID'].unique()
final_df.loc[final_df['ID'].isin(failed_ids), 'Designation Level'] += 1
final_df = final_df[final_df['Designation Level'] <= 4]

# ---------------- Task 7: Add Title & Drop Gender ----------------
final_df['First Name'] = final_df.apply(lambda row: ('Mr. ' if row['Gender']=='M' else 'Mrs. ') + row['First Name'], axis=1)
final_df.drop(columns=['Gender'], inplace=True)

# ---------------- Task 8: Promotion based on Age ----------------
final_df['Designation Level'] = np.where(
    (final_df['Age'] > 29) & (final_df['Designation Level'] > 1),
    final_df['Designation Level'] - 1,
    final_df['Designation Level']
)

# ---------------- Task 9: Total Project Cost ----------------
total_proj_cost = final_df.groupby(['ID','First Name'], as_index=False)['Cost'].sum()
total_proj_cost.rename(columns={'Cost':'Total Cost'}, inplace=True)

# ---------------- Task 10: Employees in Cities containing 'o' ----------------
city_o_df = final_df[final_df['City'].str.contains('o', case=False, na=False)].drop_duplicates(subset=['ID'])

# ---------------- Optional: Print outputs ----------------
print("\n------ Task 1–10 Completed ------")
print("\nSample Final DF:")
print(tabulate(final_df.head(), headers='keys', tablefmt='grid'))

print("\nTotal Project Cost per Employee:")
print(tabulate(total_proj_cost, headers='keys', tablefmt='grid'))

print("\nEmployees in Cities containing 'o':")
print(tabulate(city_o_df, headers='keys', tablefmt='grid'))

# ---------------- Optional: Save final CSVs ----------------
final_df.to_csv("Final.csv", index=False)
total_proj_cost.to_csv("TotalProjCost.csv", index=False)
city_o_df.to_csv("City_o_Employees.csv", index=False)

