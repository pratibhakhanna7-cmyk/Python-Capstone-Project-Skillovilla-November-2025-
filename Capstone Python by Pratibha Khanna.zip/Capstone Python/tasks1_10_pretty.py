import pandas as pd
from tabulate import tabulate  # For pretty printing

# ---------------- Task 1: Create CSVs ----------------
project_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005", "A002", "A005", "A003", "A001", "A003", "A001", "A004", "A004", "A005"],
    "Project": ["Project 1", "Project 2", "Project 3", "Project 4", "Project 5",
                "Project 6", "Project 7", "Project 8", "Project 9", "Project 10",
                "Project 11", "Project 12", "Project 13", "Project 14"],
    "Cost": [1002000, 2000000, 4500000, 5500000, None, 680000, 400000, 350000, None, 300000, 2000000, 1000000, 3000000, 200000],
    "Status": ["Finished", "Ongoing", "Finished", "Ongoing", "Finished",
               "Failed", "Finished", "Failed", "Ongoing", "Finished",
               "Failed", "Ongoing", "Finished", "Finished"]
}
project_df = pd.DataFrame(project_data)
project_df.to_csv("project_data.csv", index=False)

employee_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005"],
    "Name": ["John Alter", "Alice Luxumberg", "Tom Sabestine", "Nina Adgra", "Amy Johny"],
    "Gender": ["M", "F", "M", "F", "F"],
    "City": ["Paris", "London", "Berlin", "Newyork", "Madrid"],
    "Age": [25, 27, 29, 31, 30]
}
employee_df = pd.DataFrame(employee_data)
employee_df.to_csv("employee_data.csv", index=False)

seniority_data = {
    "ID": ["A001", "A002", "A003", "A004", "A005"],
    "Designation Level": [2, 2, 3, 2, 3]
}
seniority_df = pd.DataFrame(seniority_data)
seniority_df.to_csv("seniority_data.csv", index=False)

print("------ Task 1: CSVs Created ------")
print(tabulate(project_df, headers='keys', tablefmt='grid'))
print(tabulate(employee_df, headers='keys', tablefmt='grid'))
print(tabulate(seniority_df, headers='keys', tablefmt='grid'))

# ---------------- Task 2: Fill missing Cost using running average ----------------
running_sum = 0
count = 0
for i in range(len(project_df)):
    if pd.notna(project_df.loc[i, 'Cost']):
        running_sum += project_df.loc[i, 'Cost']
        count += 1
    else:
        project_df.loc[i, 'Cost'] = running_sum / count if count > 0 else 0
project_df['Cost'] = project_df['Cost'].astype(int)

print("\n------ Task 2: Missing Costs Filled ------")
print(tabulate(project_df, headers='keys', tablefmt='grid'))

# ---------------- Task 3: Split Name ----------------
employee_df[['First Name', 'Last Name']] = employee_df['Name'].str.split(pat=' ', n=1, expand=True)
employee_df.drop(columns=['Name'], inplace=True)
print("\n------ Task 3: Name Split ------")
print(tabulate(employee_df, headers='keys', tablefmt='grid'))

# ---------------- Task 4: Merge ----------------
final_df = project_df.merge(employee_df, on='ID', how='left').merge(seniority_df, on='ID', how='left')
print("\n------ Task 4: Merged Final DataFrame ------")
print(tabulate(final_df, headers='keys', tablefmt='grid'))

# ---------------- Task 5: Bonus ----------------
final_df['Bonus'] = final_df.apply(lambda row: 0.05*row['Cost'] if row['Status']=='Finished' else 0, axis=1)
print("\n------ Task 5: Bonus Added ------")
print(tabulate(final_df[['ID','Project','Cost','Status','Bonus']], headers='keys', tablefmt='grid'))

# ---------------- Task 6: Demotion & Removal ----------------
final_df.loc[final_df['Status']=='Failed', 'Designation Level'] += 1
final_df = final_df[final_df['Designation Level'] <= 4]
print("\n------ Task 6: Demotion & Removal ------")
print(tabulate(final_df[['ID','Project','Status','Designation Level']], headers='keys', tablefmt='grid'))

# ---------------- Task 7: Mr./Mrs. & Drop Gender ----------------
final_df['First Name'] = final_df.apply(lambda row: 'Mr. '+row['First Name'] if row['Gender']=='M' else 'Mrs. '+row['First Name'], axis=1)
final_df.drop(columns=['Gender'], inplace=True)
print("\n------ Task 7: Mr./Mrs. Added ------")
print(tabulate(final_df[['ID','First Name','Last Name']], headers='keys', tablefmt='grid'))

# ---------------- Task 8: Promotion ----------------
final_df.loc[final_df['Age']>29, 'Designation Level'] -= 1
final_df['Designation Level'] = final_df['Designation Level'].apply(lambda x: max(1,x))
print("\n------ Task 8: Promotion Applied ------")
print(tabulate(final_df[['ID','First Name','Designation Level']], headers='keys', tablefmt='grid'))

# ---------------- Task 9: Total Project Cost ----------------
total_proj_cost = final_df.groupby(['ID','First Name'], as_index=False)['Cost'].sum()
total_proj_cost.rename(columns={'Cost':'Total Cost'}, inplace=True)
print("\n------ Task 9: Total Project Cost ------")
print(tabulate(total_proj_cost, headers='keys', tablefmt='grid'))

# ---------------- Task 10: City contains 'o' ----------------
city_o_df = final_df[final_df['City'].str.contains('o', case=False, na=False)]
print("\n------ Task 10: Employees with 'o' in City ------")
print(tabulate(city_o_df, headers='keys', tablefmt='grid'))

# Optional: Save CSVs
final_df.to_csv("Final.csv", index=False)
total_proj_cost.to_csv("TotalProjCost.csv", index=False)
city_o_df.to_csv("City_o_Employees.csv", index=False)

print("\n✅ All Tasks 1–10 completed successfully!")

